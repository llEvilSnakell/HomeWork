import java.util.*
val scan = Scanner(System.`in`)

fun main(args:Array<String>){
    //Mission5/
    val year = scan.nextInt()
    getYearEra(year)

    //Mission6
    println( calculateEvenDigits("1234"))
}

fun getYearEra(item: Int){
    while (item != null){
        if(item < 1970){
            println("$item - До")
        }
        else if(item == 1970){
            println("$item - соответсвует")
        }
        else if(item > 1970 && item < 2000){
            println("$item - после (XX век)")
        }
        else if(item > 2000 && item < 3000){
            println("$item - после (XXI век)")
        }
        else{
            println("$item - далекое будущее")
        }
        val year = scan.nextInt()
        getYearEra(year);
    }
}

fun calculateEvenDigits(wage: String): Int {
    var sum: Int = 0
    for (item in wage){
        if (Character.isDigit(item)){
            var x: Int = item.digitToInt()
            if (x % 2 == 0){
                sum += x
            }
        }
    }
    return sum
}