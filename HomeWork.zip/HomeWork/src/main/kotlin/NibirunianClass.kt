//Mission8
class NibirunianClass {
    public var namePlate:String?= null
    var name = readLine()

    fun  createNamePlate (name : String){
        namePlate = "Живи долго и счастливо $name"
    }
}