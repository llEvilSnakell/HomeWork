//Mission10
open class BugCivilian: Bug(rank = 1,name = "Denis") {
    override fun getSugarLimit(): Int {
        return super.getSugarLimit()/2
    }
}