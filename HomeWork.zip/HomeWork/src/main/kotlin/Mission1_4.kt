fun main(args:Array<String>){
    //Mission1
    println("Здравствуй, о храбрый житель Королевства Жуков!\n")

    //Mission2
    var name = readLine()
    println("О могучий правитель Королевства Жуков, землянин по имени $name приветствует тебя!\n")

    //Mission3
    var varible = 0;
    var x = 0;
    while (varible < 6) {
        x = readLine()!!.toInt();
        calcChair(x)
        varible++
    }

    //Mission4
    println(cashAmount(10,2,25))
}

fun calcChair(x: Int) {
    var z = x / 2
    var y = x + z

    println(" $y\n")
}

fun cashAmount(dayNumber: Int, bugRank: Int, money: Int): Int? {
    return (dayNumber * (bugRank + 42)) * money
}