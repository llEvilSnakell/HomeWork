//Mission9
class SugarStorage {
    public var volume:Int = 0

    constructor(volume: Int) {
        this.volume = volume
    }

    fun decreaseSugar(v:Int){
        if(v < 0){
            print("отрицательное значение")
            return
        }
        else if(v >= volume) {
            volume -= v;
        }
    }

    fun increaseSugar(v:Int){
        if(v < 0){
            print("отрицательное значение")
            return
        }
        volume += v
    }
}