class SimplreClass {
    //Mission7
}