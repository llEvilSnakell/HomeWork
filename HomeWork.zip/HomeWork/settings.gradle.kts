
rootProject.name = "DomahaPanov"

